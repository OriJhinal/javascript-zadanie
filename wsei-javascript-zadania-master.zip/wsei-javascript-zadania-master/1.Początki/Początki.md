#### Zadanie 1

Wpisz w consoli następującą instrukcję:

```JavaScript
console.log("Twoje imię");
```

#### Zadanie 2

Wpisz w consoli następującą instrukcję i sprawdź ich wynik:

```JavaScript
* 12 + 32;
* 52 / 16;
* 5 * 2;
```

#### Zadanie 3

Wpisz do konsoli i sprawdź co się wyświetli:

```
*  "Hello World";
*   Hello World;
*  "Hello World;
```
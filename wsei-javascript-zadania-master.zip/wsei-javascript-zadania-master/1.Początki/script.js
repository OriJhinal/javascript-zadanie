// Zadanie 1:

console.log("Jakub Faliszewski");

// Zadanie 2:

console.log(12 +32);
console.log(52 / 16);
console.log(5 * 2);

// Zadanie 3:

console.log("Hello World");
console.log(Hello World);
console.log("Hello World);

// linia 13 - wyświetla string "Hello World"
// linia 14 - Syntax error - brak znaków "
// linia 15 - Syntax error - brak znaku "

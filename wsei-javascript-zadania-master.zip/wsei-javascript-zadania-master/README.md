# Aby zaliczyć laboratorium:

1. Obecność jest obowiązkowa i sprawdzana na początku każdych zajęć, niezależnie o trybu zajęć (stacjonarnie czy zdalnie). Można mieć jedną nieobecność. Jeśli nie było Cię więcej niż 1 raz i chcesz zaliczyć przedmiot - musisz odrobić zajęcia z inną grupą.

2. Musisz oddać komplet zrobionych zadań w postaci linka do githuba. Link ten musi być przesłany mailem na adres msowinski@wsei.edu.pl. 
    - Tytuł maila: 
        `Zaliczenie laboratorium [nr grupy]`
    - Treść maila:
        `Imię, nazwisko, numer albumu, link do githuba`

    Tylko w takiej postaci będzie przyjmowane zaliczenie. Jeśli nie będzie się zgadzać treść nie będzie zaliczenia.

3. Termin oddania zaliczenia to godzina 23.59 dnia 2021-02-07. Po tej dacie zaliczenia nie będą przyjmowane.
#### Zadanie 1

W konsoli stwórz dwie zmienne przechowujące liczby. Następnie za pomocą instrukcji warunkowej ```if ... else ```, wypisz w konsoli, która z nich jest większa.

#### Zadanie 2

W konsoli stwórz trzy zmienne przechowujące liczby. Następnie za pomocą instrukcji warunkowej **if**, **else if** i **else**
wypisz w konsoli, która z nich jest największa.


#### Zadanie 3
W konsoli stwórz pętle, która 10 razy wypisze w konsoli tekst "Lubię JavaScript".

#### Zadanie 4
W konsoli stwórz zmienną ```result``` i przypisz do niej liczbę 0. Następnie stwórz pętle, która doda do siebie liczby od 1 do 10.

#### Zadanie 5
W konsoli napisz program, który na podstawie wartości zmiennej np. ```var n = 5;``` wypisuje wszystkie liczby od zera do **n**.
Przy każdej liczbie program ma napisać, czy  liczba jest parzysta czy nie. Np.:

```JavaScript
0 – parzysta
1 – nieparzysta
2 – parzysta
3 – nieparzysta
...
```

#### Zadanie 6
W konsoli stwórz dwie pętle niezależne i wypisz wartości ich liczników w każdej iteracji. Wykorzystaj:
konkatenację np.

```JavaScript 
console.log("i= " + i + ", j= " + j);
```

#### Zadanie 7

FizzBuzz - wypisz w consoli liczby od 0 do 100. Zamiast każdej podzielnej liczby przez 3 wypisz "Fizz", zamiast każdej podzielnej liczby przez 5 wypisz "Buzz" a zamiast każdej podzielnej liczby przez 3 i przez 5 wypisz "FizzBuzz"

Przykład:

```
0 1 2 Fizz 4 Buzz Fizz 7 8 Fizz Buzz 11 Fizz 13 14 FizzBuzz ....
```

#### Zadanie 8

Narysuj w konsoli:

a)
```
*
**
***
****
*****
```

b)
```
    *
   * *
  * * *
 * * * *
* * * * *
```

c)
```
    *
   ***
  *****
 *******
*********
```

d)
```
*1234
**234
***34
****4
*****
-----
*****
****4
***34
**234
*1234
```

e)
```
    *
   * *
  * * *
 * * * *
* * * * *
    *
    *
    *
```
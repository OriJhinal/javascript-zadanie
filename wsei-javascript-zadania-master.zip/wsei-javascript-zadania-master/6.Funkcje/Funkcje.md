#### Zadanie 1

Napisz funkcję która wypisuje w konsoli "Udało się!"

#### Zadanie 2

Napisz funkcję która przyjmuje dowolny parametr i wyświetla go w konsoli

#### Zadanie 3

Napisz funkcję która przyjmuje jako parametr tablicę a następnie zwraca ją.

#### Zadanie 4

Napisz funkcję która przyjmie jako argument stringa a następnie co 3 sekundy będzie go wypisywać w konsoli. Po 5 razach ma przestać wypisywanie i zwrócić do konsoli napiś "Koniec".
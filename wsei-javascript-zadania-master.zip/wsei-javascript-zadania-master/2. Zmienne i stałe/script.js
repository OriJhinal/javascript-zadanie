// Zadanie 1:

let number = 2;
let string = "dwa";
let stringNumConcat = number + string;
let logicValue = 3 < 2;
let special = null;

console.log(number, string, stringNumConcat, logicValue, special);

// Zadanie 2:

let num0 = 12;
let num1 = 4;
let sum = 0;
sum = num0 + num1;
console.log(sum);

// Zadanie 3:

let unknown;
console.log(unknown);

// Zwracana jest wartość undefined, ponieważ zmienna nie ma przypisanej wartości
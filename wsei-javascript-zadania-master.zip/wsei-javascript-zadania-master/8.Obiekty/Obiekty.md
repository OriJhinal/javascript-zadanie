#### Zadanie 1

Stwórz obiekt car i dopisz do niego różne właściwości. Wypisz właściwości w konsoli

#### Zadanie 2

Na podstawie obiektu z zadania 1 dopisz do niego metodę zmieniającą jego nazwę na podstawie parametru przekazanego z wywołania metody.

#### Zadanie 3

Stwórz obiekt z metodą sumującą wszystkie liczby z tablicy podanej w parametrze w wywołaniu tej metody. Następnie metoda ta powinna zapisywać wynik we właściwości sum tego obiektu. Na koniec wypisz właściwość sum w konsoli.

#### Zadanie 4

Stwórz obiekt car. Następnie wypisz w konsoli informacje na jego temat na podany poniżej wzór:

name: BMW
age: 12
...

Czy pary klucz wartość.

#### Zadanie 5

Stwórz dowolny obiek w obiekcie car. Następnie wypisz w konsoli jego właściwości.

#### Zadanie 6

Do obiektu car dodaj dowolną właściwość oraz metodę wypisującą w konsoli napis "Hello". Zrób to poza ciałem obiektu.
#### Zadanie 1

Stwórz następujące eventy i sprawdź co udostępnia ich obiekt event:

1. Kliknięcie w przycisk o id="test-event"
2. Ruch myszką na ekranie
3. Najechanie myszką na przycisk o id="test-event"
4. naciśnięcie klawisza na klawiaturze
5. scrollowanie strony w dół i w górę
6. zmianę tekstu w input id="input-test"

#### Zadanie 2

Napisz funkcję która po kliknięciu na button id="ex2" pobierze tekst z jego data atrybutu a następnie wpisze ten tekst do spanu który jest poniżej.

#### Zadanie 3

Napisz funkcję która po najechaniu na czerwony kwadrat zmieniu jego kolor na niebieski. Następnie po zjechaniu myszki z obszaru kwadratu zmieni się z powrotem na czerwony.

#### Zadanie 4

Napisz funkcję walidacyjną dla input id="input-test". Funkcja ma za zadanie sprawdzać co jest wpisane w inputa. Jeśli user wpisze jakąś cyfrę pokaż mu komunikat błędu pod inputem informujący że nie może wpisywać cyfr.

#### Zadanie 5

Napisz funkcję countera. Funkcja ma za zadanie wpisywać do spanu w divie id="ex5" numerka odpowiadającego ilości kliknięć w button id="ex5-button". Jeśli licznik dojdzie do 10 event powinien być usunięty.

#### Zadanie 6

Napisz funkcję która będzie obserwowac scroll strony. Jeśli scroll zjedzie poniżej 200px zmień kolor strony na czerwony. Jeśli będzie powyżej 200px niech zmieni kolor na biały.

#### Zadanie 7

Napisz obsługę kalkulatora. Dodaj odpowiednie eventy do przycisków. Wynik wyświetlaj w inpucie. Staraj się aby funkcje były reużywalne.
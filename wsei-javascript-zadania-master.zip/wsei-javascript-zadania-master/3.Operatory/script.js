// Zadanie 1:
let bool1 = true;
let bool2 = false;

console.log(bool1 === bool2);

// Zadanie 2:

let num1 = 12;
let num2 = 5;
let moduloResult = 0;
moduloResult = num1 % num2;

console.log(moduloResult);

// Zadanie 3:

let str1 = `Lorem`;
let str2 = `Ipsum`;
let stringsResult = "";
stringsResult = str1 + str2;

console.log(stringsResult);


// Zadanie 4:

var someNumber = 425;
var someString = "425";

console.log(someNumber == someString);
console.log(someNumber === someString);

// Operator == porównuje wartości, a === wartości oraz typy.

// Zadanie 5:
let counter = 30;
console.log(counter);
counter++;
console.log(counter);
counter--;
console.log(counter);


// Zadanie 6:
let num3 = 12;
let num4 = 5;
let result = 0;

result = num3 > num4;
console.log(result);
#### Zadanie 1

W konsoli stwórz dwie zmienne i przypisz do nich dwie wartości boolean. Porównaj je za pomocą odpowiedniego operatora.

#### Zadanie 2

W konsoli stwórz trzy zmienne. Dwie niech przechowują dowolne liczby, a trzecia o nazwie ```moduloResult``` niech przechowuje liczbę 0. Oblicz resztę z dzielenia (modulo) tych liczb i zapisz wynik w zmiennej ```moduloResult```.
Wypisz zmienną ```moduloResult``` w konsoli. 

#### Zadanie 3
W konsoli stwórz trzy zmienne. Dwie niech przechowują dowolne stringi, a jedna o nazwie ```stringsResult```, niech przechowuje pusty string np. ```let stringsResult = ""```
Połącz stringi za pomocą konkatenacji i zapisz wynik w zmiennej ```stringsResult``` oraz wypisz go w konsoli.

#### Zadanie 4
W konsoli stwórz dwie zmienne:

 ``` JavaScript
var someNumber = 425;
var someString = "425";
 ```

Porównaj te zmienne za pomocą operatorów ```==``` oraz ```===```.
Wypisz wyniki w konsoli. Opowiedz grupie o wynikach


#### Zadanie 5

W konsoli stwórz zmienną o nazwie ```counter```. Wstaw do niej liczbę 30.
Wypisz jej wartość w konsoli, a następnie:

* za pomocą inkrementacji zwiększ wartość zmiennej ```counter```
* wypisz ją w konsoli
* za pomocą dekrementacji zmniejsz wartość zmiennej ```counter```
* wypisz ją w konsoli.


#### Zadanie 6

W konsoli stwórz trzy zmienne. Dwie niech przechowują dowolne liczby, a jedna o nazwie ```result```, niech przechowuje ```null```. Sprawdź czy liczba pierwsza jest większa od drugiej za pomocą odpowiedniego operatora i zapisz wynik w zmiennej ```result```. Wypisz tą zmienną w konsoli.